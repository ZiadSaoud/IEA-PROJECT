module IEA_PROJECT {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.base;
	requires java.desktop;
	
	opens SmartAgent to javafx.graphics, javafx.fxml;
}
